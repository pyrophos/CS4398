package com.example.wwjdt.utils;

/**
 * Created by wwjdt on 3/17/2016.
 */
public class Constants {

    public static final String KEY_UNM = "username";
    public static final String KEY_PWD= "password";


}
