package com.example.wwjdt.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.widget.Toast;

/**
 * Created by wwjdt on 3/17/2016.
 */
public class appUtils {

    public static void toast(Context ctx, String msg)
    {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();;
    }
    public static int checkLogin(Context ctx, String unm, String pwd)
    {
        SharedPreferences pref= PreferenceManager.getDefaultSharedPreferences(ctx);
        String punm = pref.getString(Constants.KEY_UNM, "");
        String ppwd = pref.getString(Constants.KEY_PWD, "");

        if(punm.length()==0){
            return 0;

        }else if(punm.equals(unm)&&ppwd.equals(pwd)){
            return 1;

        }else{
            return 2;
        }

    }
}
