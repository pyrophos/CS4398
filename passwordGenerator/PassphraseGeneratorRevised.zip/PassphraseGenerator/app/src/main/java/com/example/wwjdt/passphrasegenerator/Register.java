package com.example.wwjdt.passphrasegenerator;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;
import android.preference.PreferenceManager;

import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.example.wwjdt.utils.Constants;
import com.example.wwjdt.utils.appUtils;

import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;


public class Register extends AppCompatActivity implements View.OnClickListener {

    private Button registerButton, backButton;
    private EditText editUsername, editPassword;
    private Context mctx;

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editUsername = (EditText) findViewById(R.id.editUsername);
        editPassword = (EditText) findViewById(R.id.editPassword);

        backButton.setOnClickListener(this);
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    public void onClick(View v) {

        switch(v.getId()){

            case R.id.backButton:
                startActivity(new Intent(this, Login.class));
                break;

        }

    }

    public void save(View v) {
        String usernameText = editUsername.getText().toString().trim();
        String passwordText = editPassword.getText().toString().trim();

        if (usernameText.length() == 0) {
            editUsername.setText("Enter username");

        } else if (passwordText.length() == 0) {
            editPassword.setText("Enter password");
        } else {
            SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(mctx);
            SharedPreferences.Editor edit = pref.edit();
            edit.putString(Constants.KEY_UNM, usernameText);
            edit.putString(Constants.KEY_PWD, passwordText);
            edit.commit();
            finish();
            appUtils.toast(mctx, "Registered");

        }


    }


}


