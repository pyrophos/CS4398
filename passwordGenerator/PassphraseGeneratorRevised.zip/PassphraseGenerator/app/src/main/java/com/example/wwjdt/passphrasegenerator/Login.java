package com.example.wwjdt.passphrasegenerator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.example.wwjdt.utils.appUtils;

public class Login extends AppCompatActivity implements View.OnClickListener {

    private Button loginButton, registerButton;
    private EditText editUsername, editPassword;
    private Context mctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editUsername = (EditText) findViewById(R.id.editUsername);
        editPassword = (EditText) findViewById(R.id.editPassword);
        loginButton = (Button) findViewById(R.id.loginButton);
        registerButton = (Button) findViewById(R.id.registerButton);

        loginButton.setOnClickListener(this);
        registerButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v==loginButton) {
            isLogin();
        }else if(v==registerButton){
            startActivity(new Intent(Login.this, Register.class));
        }

    }

    private void isLogin(){

        String unm = editUsername.getText().toString().trim();
        String pwd = editPassword.getText().toString().trim();
        if(unm.length()==0)
        {
            editUsername.setError("Enter Username");

        }else if(pwd.length()==0){
            editPassword.setError("Enter Password");
        }else{
            int res= appUtils.checkLogin(mctx, unm, pwd);
            if(res==0)
            {
                appUtils.toast(mctx, "Please register");
            }else if (res ==1)
            {
                Intent intent = new Intent (this, content.class);
                intent.putExtra("user", unm);
                startActivity(intent);

            }else if (res == 2)
            {
                appUtils.toast(mctx, "Please enter valid username or password");
            }
        }

    }
}
