package com.example.wwjdt;

/**
 * Created by wwjdt on 3/31/2016.
 */
public class CredentialOptions {
}
