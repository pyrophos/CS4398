package com.example.wwjdt.passphrasegenerator;

/**
 * Created by wwjdt on 3/29/2016.
 */
public class AppConstants
{
    public static final int MIN_WORDS = 1;
    public static final int MAX_WORDS = 15;
    public static final int MIN_CHARS = 1;
    public static final int MAX_CHARS = 256;

}